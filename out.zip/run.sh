onyx run --save-injected tmp.onyx main.onyx
